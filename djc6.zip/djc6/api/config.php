<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'djc6');
define('DB_PASSWORD', 'djc6');
define('DB_HOST', 'localhost');
// define('DB_NAME', 'angularcode');
define('DB_NAME', 'djc6');

?>
